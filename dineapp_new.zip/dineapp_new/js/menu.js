const menuData = {
    "Veg": [
      { name: "Paneer Butter Masala", price: 180 },
      { name: "Dal Tadka", price: 120 },
      { name: "Aloo Gobi", price: 150 },
      { name: "Veg Biryani", price: 200 },
      { name: "Veg Pulao", price: 130 },
      { name: "Methi Thepla", price: 110 },
      { name: "Palak Paneer", price: 160 },
      { name: "Chana Masala", price: 140 },
      { name: "Mixed Veg", price: 170 },
      { name: "Gobi Manchurian", price: 180 }
    ],
    "Non-Veg": [
      { name: "Chicken Biryani", price: 250 },
      { name: "Butter Chicken", price: 220 },
      { name: "Fish Curry", price: 300 },
      { name: "Mutton Korma", price: 280 },
      { name: "Tandoori Chicken", price: 210 },
      { name: "Chicken Kebab", price: 200 },
      { name: "Prawn Masala", price: 320 },
      { name: "Chicken Tikka", price: 230 },
      { name: "Mutton Biryani", price: 270 },
      { name: "Kadhai Chicken", price: 240 }
    ],
    "Veg Starters": [
      { name: "Veg Pakora", price: 120 },
      { name: "Veg Samosa", price: 60 },
      { name: "Spring Rolls", price: 150 },
      { name: "Hara Bhara Kebab", price: 180 },
      { name: "Paneer Tikka", price: 220 },
      { name: "Chana Chaat", price: 110 },
      { name: "Vegetable Cutlet", price: 130 },
      { name: "Aloo Tikki", price: 100 },
      { name: "Corn and Cheese Balls", price: 160 },
      { name: "Onion Rings", price: 90 }
    ],
    "Non-Veg Starters": [
      { name: "Chicken Wings", price: 180 },
      { name: "Fish Amritsari", price: 240 },
      { name: "Mutton Seekh Kebab", price: 250 },
      { name: "Prawn Koliwada", price: 270 },
      { name: "Tandoori Prawns", price: 300 },
      { name: "Chicken Pakora", price: 220 },
      { name: "Mutton Shami Kebab", price: 230 },
      { name: "Chicken Malai Tikka", price: 260 },
      { name: "Mutton Boti Kebab", price: 280 },
      { name: "Chicken Reshmi Kebab", price: 250 }
    ],
    "Tiffins": [
      { name: "Masala Dosa", price: 90 },
      { name: "Idli Sambar", price: 80 },
      { name: "Medu Vada", price: 70 },
      { name: "Pesarattu", price: 100 },
      { name: "Upma", price: 80 },
      { name: "Poori Bhaji", price: 120 },
      { name: "Chole Bhature", price: 140 },
      { name: "Aloo Paratha", price: 110 },
      { name: "Methi Thepla", price: 120 },
      { name: "Rawa Dosa", price: 110 }
    ],
    "Desserts & Drinks": [
      { name: "Gulab Jamun", price: 60 },
      { name: "Ras Malai", price: 100 },
      { name: "Chocolate Lava Cake", price: 150 },
      { name: "Ice Cream", price: 80 },
      { name: "Gajar Halwa", price: 120 },
      { name: "Kulfi", price: 90 },
      { name: "Lassi", price: 70 },
      { name: "Mango Milkshake", price: 80 },
      { name: "Sweet Lassi", price: 60 },
      { name: "Fruit Salad", price: 100 }
    ],
    "Curd Products": [
      { name: "Curd Rice", price: 130 },
      { name: "Dahi Puri", price: 120 },
      { name: "Raita", price: 60 },
      { name: "Dahi Vada", price: 90 },
      { name: "Lassi (Sweet)", price: 70 },
      { name: "Mango Lassi", price: 80 },
      { name: "Dahi Bhalla", price: 100 },
      { name: "Chaas (Buttermilk)", price: 50 },
      { name: "Cucumber Raita", price: 80 },
      { name: "Pineapple Raita", price: 90 }
    ],
    "Cool Drinks": [
      { name: "Cold Coffee", price: 120 },
      { name: "Fruit Punch", price: 100 },
      { name: "Lemon Soda", price: 80 },
      { name: "Ice Tea", price: 90 },
      { name: "Iced Lemonade", price: 85 },
      { name: "Mint Mojito", price: 110 },
      { name: "Coconut Water", price: 60 },
      { name: "Guava Juice", price: 70 },
      { name: "Pineapple Juice", price: 75 },
      { name: "Watermelon Juice", price: 80 }
    ]
  };
  
  // Generate Menu Sections Dynamically
  function generateMenu() {
    const menuSections = document.getElementById('menu-sections');
    Object.keys(menuData).forEach(section => {
      const sectionDiv = document.createElement('div');
      sectionDiv.classList.add('menu-section');
      sectionDiv.innerHTML = `<h2>${section}</h2>`;
  
      menuData[section].forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('menu-item');
        itemDiv.innerHTML = `
          <span>${item.name} - ₹${item.price}</span>
          <div class="controls">
            <button class="decrease" onclick="updateQuantity('${section}', '${item.name}', -1)">-</button>
            <span id="${section}-${item.name}-quantity">0</span>
            <button class="increase" onclick="updateQuantity('${section}', '${item.name}', 1)">+</button>
          </div>
        `;
        sectionDiv.appendChild(itemDiv);
      });
  
      menuSections.appendChild(sectionDiv);
    });
  }
  
  // Update Quantity and Total Price
  function updateQuantity(section, itemName, change) {
    const quantityElement = document.getElementById(`${section}-${itemName}-quantity`);
    let quantity = parseInt(quantityElement.textContent);
    quantity = Math.max(0, quantity + change); // Prevent negative values
    quantityElement.textContent = quantity;
    updateTotalPrice();
  }
  
  function updateTotalPrice() {
    let total = 0;
    Object.keys(menuData).forEach(section => {
      menuData[section].forEach(item => {
        const quantity = parseInt(document.getElementById(`${section}-${item.name}-quantity`).textContent);
        total += quantity * item.price;
      });
    });
    document.getElementById('total-price').textContent = total;
  }
  
  // Confirm Order and Show Summary
  function confirmOrder() {
    const summaryList = document.getElementById('summary-list');
    summaryList.innerHTML = '';
    let totalPrice = 0;
  
    Object.keys(menuData).forEach(section => {
      menuData[section].forEach(item => {
        const quantity = parseInt(document.getElementById(`${section}-${item.name}-quantity`).textContent);
        if (quantity > 0) {
          const subtotal = item.price * quantity;
          totalPrice += subtotal;
  
          const listItem = document.createElement('li');
          listItem.textContent = `${item.name} x${quantity} - ₹${subtotal}`;
          summaryList.appendChild(listItem);
        }
      });
    });
  
    document.getElementById('summary-total').textContent = totalPrice;
    document.getElementById('order-summary').style.display = 'block';
  }
  
  // Save Pre-Order Data to localStorage and Go to Confirmation
  function proceedToConfirmation() {
    const items = [];
    const summaryItems = document.querySelectorAll('#summary-list li');
  
    summaryItems.forEach(li => {
      const [itemPart, pricePart] = li.textContent.split(' - ₹');
      const [name, quantity] = itemPart.split(' x');
      const price = parseInt(pricePart);
  
      items.push({
        itemName: name.trim(),
        itemQuantity: quantity.trim(),
        itemSubtotal: price
      });
    });
  
    localStorage.setItem('preOrderData', JSON.stringify(items));
    window.location.href = 'confirmation.html';
  }
  
  // Initialize Menu on Page Load
  window.onload = generateMenu;