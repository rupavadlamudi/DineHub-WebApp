document.querySelector(".signup-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission for now
  
    const name = document.querySelector("#name").value;
    const emailOrPhone = document.querySelector("#emailOrPhone").value;
    const password = document.querySelector("#password").value;
  
    // Basic validation
    if (name && emailOrPhone && password) {
      alert("Sign Up Successful!");
  
      // Redirect user to the Login page
      window.location.href = "login.html";
    } else {
      alert("Please fill in all fields.");
    }
  });
  