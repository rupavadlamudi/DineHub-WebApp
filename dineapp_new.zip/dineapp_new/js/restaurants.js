const sampleRestaurants = [
    { name: "Ocean Breeze", location: "Beach Side", rating: 4.5 },
    { name: "Park Diner", location: "City Park", rating: 4.3 },
    { name: "Mountain Grill", location: "Hill View", rating: 4.7 },
    { name: "River Café", location: "Riverside", rating: 4.2 },
    { name: "Urban Spice", location: "Downtown", rating: 4.6 },
    { name: "Star Chef", location: "Food Street", rating: 4.8 }
  ];
  
  function displayRestaurants(restaurants) {
    const container = document.getElementById("restaurantsContainer");
    container.innerHTML = "";
    restaurants.forEach((res) => {
      container.innerHTML += `
        <div class="card">
          <h3>${res.name}</h3>
          <p>📍 ${res.location}</p>
          <p class="rating">⭐ ${res.rating}</p>
          <button onclick="window.location.href='restaurant.html'">Reserve Now</button>
        </div>
      `;
    });
  }
  
  function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        () => {
          alert("Location found! Showing restaurants near you.");
		  navigator.geolocation.getCurrentPosition(showLoc, errHand);
          displayRestaurants(sampleRestaurants);
        },
        () => {
          alert("Location denied. Showing default restaurants.");
          displayRestaurants(sampleRestaurants);
        }
      );
    } else {
      alert("Geolocation not supported.");
      displayRestaurants(sampleRestaurants);
    }
  }
  
  function showLoc(pos) {
			latt = pos.coords.latitude;
			long = pos.coords.longitude;
			var lattlong = new google.maps.LatLng(latt, long);
			var OPTions = {
				center: lattlong,
				zoom: 10,
				mapTypeControl: true,
				navigationControlOptions: {
					style: google.maps.NavigationControlStyle.SMALL,
				},
			};
			var mapg = new google.maps.Map(
				document.getElementById("demo2"),
				OPTions
			);
			var markerg = new google.maps.Marker({
				position: lattlong,
				map: mapg,
				title: "You are here!",
			});
		}

		function errHand(err) {
			switch (err.code) {
				case err.PERMISSION_DENIED:
					result.innerHTML =
						"The application doesn't have the permission" +
						"to make use of location services";
					break;
				case err.POSITION_UNAVAILABLE:
					result.innerHTML = 
						"The location of the device is uncertain";
					break;
				case err.TIMEOUT:
					result.innerHTML = 
						"The request to get user location timed out";
					break;
				case err.UNKNOWN_ERROR:
					result.innerHTML =
						"Time to fetch location information exceeded" +
						"the maximum timeout interval";
					break;
			}
		}