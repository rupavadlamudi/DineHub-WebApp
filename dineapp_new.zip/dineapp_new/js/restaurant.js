// Mock data for restaurants
const restaurantDataHyderabad = {
    "Ocean Breeze": [
      { name: "Tandoor Restaurant", location: "Banjara Hills", rating: 4.5 },
      { name: "The Fisherman's Wharf", location: "Kondapur", rating: 4.2 },
      { name: "The Water Front", location: "Gachibowli", rating: 4.6 },
      { name: "Fusion 9", location: "Madhapur", rating: 4.4 },
      { name: "The Taj Mahal", location: "Srinagar Colony", rating: 4.7 }
    ],
    "Park Diner": [
      { name: "Park Hotel", location: "Somajiguda", rating: 4.4 },
      { name: "Rain Tree", location: "Banjara Hills", rating: 4.6 },
      { name: "Leela Palace", location: "Durgam Cheruvu", rating: 4.3 },
      { name: "The Park", location: "Hyderabad", rating: 4.5 },
      { name: "Spice Garden", location: "Hitech City", rating: 4.2 }
    ],
    "Mountain Grill": [
      { name: "Grill House", location: "Jubilee Hills", rating: 4.7 },
      { name: "Hill View", location: "Kukatpally", rating: 4.3 },
      { name: "Mountain Creek", location: "Ameerpet", rating: 4.6 },
      { name: "Sky Grill", location: "Gachibowli", rating: 4.5 },
      { name: "Sizzling Stone", location: "Lingampally", rating: 4.4 }
    ],
    "River Café": [
      { name: "Riverside Retreat", location: "Vengalrao Nagar", rating: 4.3 },
      { name: "Blue River", location: "Madhapur", rating: 4.2 },
      { name: "The Riverside Café", location: "Secunderabad", rating: 4.5 },
      { name: "Riverside Grill", location: "Kondapur", rating: 4.4 },
      { name: "River View", location: "Ameerpet", rating: 4.6 }
    ],
    "Urban Spice": [
      { name: "Spicy Affair", location: "Banjara Hills", rating: 4.7 },
      { name: "Spice Garden", location: "Gachibowli", rating: 4.4 },
      { name: "Urban Spice", location: "Madhapur", rating: 4.3 },
      { name: "Hyderabad Spices", location: "Hitech City", rating: 4.5 },
      { name: "Spice Route", location: "Kukatpally", rating: 4.6 }
    ],
    "Star Chef": [
      { name: "Star Cuisine", location: "Gachibowli", rating: 4.8 },
      { name: "Chef's Table", location: "Kondapur", rating: 4.7 },
      { name: "Royal Chef", location: "Madhapur", rating: 4.5 },
      { name: "Master Chef", location: "Banjara Hills", rating: 4.6 },
      { name: "Kitchen Star", location: "Hitech City", rating: 4.4 }
    ]
  };
  
  const restaurantDataBangalore = {
    "Ocean Breeze": [
      { name: "Novotel", location: "Hitech City", rating: 4.5,link:"http://maps.google.com/maps?&q=17.4729+78.3727"},
      { name: "The Fisherman's Wharf", location: "Koramangala", rating: 4.3 },
      { name: "Fenny's", location: "MG Road", rating: 4.7 },
      { name: "The Olive Bar & Kitchen", location: "Jayanagar", rating: 4.6 },
      { name: "Nandhana Palace", location: "Yelahanka", rating: 4.4 }
    ],
    "Park Diner": [
      { name: "The Park", location: "Whitefield", rating: 4.4 },
      { name: "Rain Tree", location: "Ulsoor", rating: 4.5 },
      { name: "Leela Palace", location: "MG Road", rating: 4.3 },
      { name: "Kailash Parbat", location: "Indiranagar", rating: 4.2 },
      { name: "Spice Garden", location: "Koramangala", rating: 4.6 }
    ],
    "Mountain Grill": [
      { name: "Grill House", location: "Jayanagar", rating: 4.5 },
      { name: "Mountain Creek", location: "Bangalore West", rating: 4.6 },
      { name: "Sky Grill", location: "Sarjapur", rating: 4.4 },
      { name: "Grill & Chills", location: "Hennur", rating: 4.7 },
      { name: "Sizzling Stone", location: "MG Road", rating: 4.3 }
    ],
    "River Café": [
      { name: "The Riverside Café", location: "Bangalore East", rating: 4.5 },
      { name: "Riverside Retreat", location: "Koramangala", rating: 4.2 },
      { name: "River View", location: "Whitefield", rating: 4.6 },
      { name: "Blue River", location: "Banashankari", rating: 4.3 },
      { name: "The Water Front", location: "Hebbal", rating: 4.4 }
    ],
    "Urban Spice": [
      { name: "Urban Spice", location: "Indiranagar", rating: 4.7 },
      { name: "Spice Route", location: "Bangalore South", rating: 4.6 },
      { name: "Spicy Affair", location: "Kormangala", rating: 4.4 },
      { name: "The Urban Curry", location: "Jayanagar", rating: 4.5 },
      { name: "Taste of Spice", location: "Malleswaram", rating: 4.3 }
    ],
    "Star Chef": [
      { name: "Master Chef", location: "Whitefield", rating: 4.8 },
      { name: "Star Cuisine", location: "MG Road", rating: 4.6 },
      { name: "Chef's Table", location: "Sarjapur", rating: 4.7 },
      { name: "Royal Chef", location: "Ulsoor", rating: 4.5 },
      { name: "The Star Plate", location: "Bangalore East", rating: 4.4 }
    ]
  };
  
  // Handle restaurant selection
  let selectedRestaurant = null;
  
  // Function to handle restaurant card selection
  function selectRestaurant(restaurantName) {
    const cards = document.querySelectorAll('.restaurant-card');
    cards.forEach(card => card.classList.remove('selected'));
  
    const selectedCard = document.querySelector(`[data-restaurant="${restaurantName}"]`);
    selectedCard.classList.add('selected');
  
    selectedRestaurant = restaurantName;
    localStorage.setItem('restaurantName', selectedRestaurant);
  
    document.getElementById('proceedToBookingBtn').style.display = 'block';
  }
  
  // Get data for selected location/view
  function getRestaurantData(location, view) {
    const data = location === 'Hyderabad' ? restaurantDataHyderabad : restaurantDataBangalore;
    return data[view];
  }
  
  // Show cards after location/view selection
  function proceedToShowRestaurants() {
    const location = document.getElementById('location').value.trim();
    const view = document.getElementById('view').value;
  
    if (!location || !view) {
      alert('Please enter a valid location and select a view.');
      return;
    }
  
    const restaurantData = getRestaurantData(location, view);
    const container = document.getElementById('restaurant-cards-container');
    container.innerHTML = '';
  
    restaurantData.forEach(restaurant => {
      const card = document.createElement('div');
      card.classList.add('restaurant-card');
      card.dataset.restaurant = restaurant.name;
      card.innerHTML = `
        <h3>${restaurant.name}</h3>
        <p><strong>Location:</strong> ${restaurant.location}</p>
        <p><strong>Rating:</strong> ${restaurant.rating}</p>
		<p><strong>Navigate:</strong><a href=${restaurant.link} target="_blank">click</a></p>
      `;
      card.addEventListener('click', () => selectRestaurant(restaurant.name));
      container.appendChild(card);
    });
  }
  
  // ✅ Redirect to booking page after restaurant selection
  function proceedToBooking() {
    const restaurantName = selectedRestaurant || localStorage.getItem('restaurantName');
    if (!restaurantName) {
      alert('Please select a restaurant first.');
      return;
    }
    localStorage.setItem('restaurantName', restaurantName);
    window.location.href = 'booking.html';
  }
  
  // Current location placeholder
  function getCurrentLocation() {
    alert('Current location feature is not implemented yet.');
  }
  