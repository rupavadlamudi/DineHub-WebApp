document.addEventListener("DOMContentLoaded", () => {
    // Load booking details from localStorage
    const tableNumber = localStorage.getItem("tableNumber") || "N/A";
    const bookingDate = localStorage.getItem("bookingDate") || "N/A";
    const bookingTime = localStorage.getItem("bookingTime") || "N/A";
    const restaurantName = localStorage.getItem("restaurantName") || "Our Restaurant";

    // Set values in confirmation page
    document.getElementById("tableNumber").textContent = tableNumber;
    document.getElementById("bookingDate").textContent = bookingDate;
    document.getElementById("bookingTime").textContent = bookingTime;

    // Load total amount from localStorage
    const totalAmount = localStorage.getItem("totalAmount") || "₹0.00";
    document.getElementById("totalAmount").textContent = totalAmount;

    // Done button event
    document.getElementById("doneBtn").addEventListener("click", () => {
        // Hide booking and amount sections
        document.getElementById("bookingDetails").style.display = "none";
        document.getElementById("amountSection").style.display = "none";
        document.getElementById("doneBtn").style.display = "none";

        // Show thank-you section with quotes and back button
        const thankYouSection = document.getElementById("thankYouSection");
        thankYouSection.style.display = "block";
    });
});
