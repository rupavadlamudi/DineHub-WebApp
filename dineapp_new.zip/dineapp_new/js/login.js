document.querySelector(".login-form").addEventListener("submit", function(event) {
    event.preventDefault();
  
    const emailOrPhone = document.querySelector("#emailOrPhone").value;
    const password = document.querySelector("#password").value;
  
    if (emailOrPhone && password) {
      alert("Login successful!");
  
      // ✅ Redirect to the restaurants page
      window.location.href = "restaurants.html";
    } else {
      alert("Please fill in both fields.");
    }
  });
  