window.addEventListener('DOMContentLoaded', function () {
    document.getElementById('booking-form').addEventListener('submit', function (e) {
        e.preventDefault();

        const name = document.getElementById('name').value;
        const phone = document.getElementById('phone').value;
        const people = document.getElementById('people').value;
        const date = document.getElementById('date').value;
        const time = document.getElementById('time').value;
        const specialRequest = document.getElementById('special-request').value;

        const tableNumber = Math.floor(Math.random() * 20) + 1;

        const bookingData = {
            name,
            phone,
            people,
            date,
            time,
            specialRequest,
            tableNumber
        };
        localStorage.setItem('bookingData', JSON.stringify(bookingData));

        // ✅ Store restaurant name, date, and time separately
        const selectedRestaurant = localStorage.getItem('selectedRestaurantName') || "Unknown Restaurant";
        localStorage.setItem('restaurantName', selectedRestaurant);
        localStorage.setItem('bookingDate', date);
        localStorage.setItem('bookingTime', time);

        document.getElementById('booking-form-container').style.display = 'none';
        document.getElementById('confirmation-message').style.display = 'block';

        document.getElementById('table-number').innerText = tableNumber;
        document.getElementById('date-time').innerText = `${date} at ${time}`;
        document.getElementById('special-request-text').innerText = specialRequest || 'No special requests';

        document.getElementById('preorder-button').addEventListener('click', function () {
            window.location.href = "menu.html";
        });

        document.getElementById('finish-button').addEventListener('click', function () {
            alert("Thank you for your booking!");
            window.location.href = "index.html";
        });
    });
});
